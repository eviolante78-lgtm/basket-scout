# Basket Scout - GitHub Pages

1. Crea nuovo repo su GitHub: basket-scout
2. Carica questi 4 file: index.html, manifest.json, sw.js, icon-192.png, icon-512.png
3. Vai su Settings > Pages > Source: Deploy from branch main / root
4. Attendi 1 minuto, link sarà https://TUOUSERNAME.github.io/basket-scout/
5. Apri su tablet > Installa app
